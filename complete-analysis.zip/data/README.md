# Local data setup

Use the Excel workbooks supplied for the course and place them directly in this folder. They are not included in this public repository.

| Filename | Worksheet | Original rows | SHA-256 |
|---|---|---:|---|
| `1 - PC Console VGCHARTZ Data 2024.xlsx` | `vgchartz-2024-ordered` | 64,016 | `c1a378b0fb95e168a02b4195ec9d867dae92ec9c592ea55b9d63c5484d9d6e1b` |
| `2 - PC Gamalytic Scraped.xlsx` | `GameAnalytics` | 121,942 | `100920b8ea8e4662d39dac1f19e55756b2d3a7b6110ed8b85f1a865730c4999f` |

The scripts read these files without changing them. The row count refers to data rows, excluding the header and empty rows. If your file has a different fingerprint, it may be another version and the published numbers may not match exactly.

The third supplied workbook, `3 - Mobile Games.xlsx`, is not required by this analysis. It contains a selected set of high-revenue games and was not used to infer broad mobile-market trends.

All workbook files and locally generated row-level audit tables are excluded by `.gitignore`. Aggregate model outputs are available in [`results/`](../results/) so teammates can inspect the findings without running Python.
