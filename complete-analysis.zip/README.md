# Square Enix: Four Data-Supported Findings

An exploratory analysis for our CAES9821 group discussion. The aim is to compare four possible findings and select three that best complement the group's report.

**Start here:** [Findings in plain English](docs/findings.md) · [Analysis methods](docs/methodology.md) · [Results chart (PDF)](figures/four_trend_options.pdf)

## The four options

| Finding | Data source | Analysis method |
|---|---|---|
| **1. Regional positioning:** Historical PlayStation RPG sales were relatively more Japan-oriented than shooter sales. | Course VGChartz workbook; 398 game–platform records from 2000–2018. | Multiple regression of the log Japan-to-North-America sales ratio, with controls and a genre-by-console interaction. |
| **2. Language support:** Square Enix Steam titles supporting more languages generally had higher estimated sales, including after major-franchise controls. | Course Gamalytic/Steam workbook; 96 Square Enix titles from 2015–2025. | Multiple regression of log sales, with price, score, release-year, genre and franchise controls. |
| **3. Genre patterns beyond blockbusters:** Positive RPG and simulation sales associations also appeared at the conditional median. | Gamalytic/Steam workbook; 90,770 paid-at-observation titles from 2015–2025. | Multiple regression and median regression, plus checks excluding top-selling titles. |
| **4. Changing release mix:** Casual titles had a higher share in later Steam release cohorts, with most growth early in the period. | Gamalytic/Steam workbook; 107,101 titles from 2015–2025. | Annual comparisons and an exploratory piecewise logistic regression. |

These are observed associations, **not estimates of causal sales gains or profitability**. The fourth finding describes the composition of a catalogue snapshot by first-release year, not consumer demand. Genre tags can overlap.

![Four findings with effect sizes and uncertainty](figures/four_trend_options.png)

## How the analysis was done

1. Read the teacher-provided Excel workbooks and record their SHA-256 fingerprints.
2. Define a sample appropriate to each question; handle duplicates, missing fields and overlapping tags explicitly.
3. Fit interpretable regression models, with log sales or log regional ratios where appropriate.
4. Check the specific alternative explanation relevant to each finding: small rounded regional sales, franchise composition, blockbusters, or free-title/publisher composition.
5. Save model summaries, coefficients, confidence intervals and figures, and distinguish what the evidence supports from what it cannot establish.

See [methodology.md](docs/methodology.md) for the exact filters, formulas and inference choices. The methods were exploratory; no claim of preregistration is made.

## Reproduce the analysis

Raw course data are not redistributed. Group members can use their own copies of the two workbooks. See [data/README.md](data/README.md) for exact filenames and checksums.

Tested with Python 3.12.14. From the repository root:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
# Put the two course Excel workbooks in data/ first.
python scripts/run_all.py
```

The run regenerates the four sets of results and figures. It also writes row-level audit files locally; these and the workbooks are ignored by Git. Published files are the code, explanations, aggregate results and figures.

## Repository guide

```text
docs/            Plain-English findings and detailed methodology
scripts/         Portable analysis and chart-generation scripts
results/         Aggregate results, model summaries and coefficient tables
figures/         PNG and PDF figures
data/README.md   How to supply the original course data locally
requirements.txt
```

- [Regional results](results/regional/results.json)
- [Square Enix language-support results](results/localization/results.json)
- [Steam genre results](results/steam_genre/results.json)
- [Release-cohort results](results/temporal/temporal_results.json)

## Scope and limitations

This repository documents an analysis of the supplied course snapshots, prepared on **5 October 2026**. Steam sales are vendor estimates of cumulative sales. Prices, language support, review scores and tags reflect the supplied snapshot and may differ from their release-time values. Budgets, marketing and IP strength are not fully observed; model confidence intervals do not include source coverage or vendor estimation error.

The supplied mobile workbook is a selected high-revenue sample and is not used to make general mobile-market claims here. No raw course materials, credentials or personal local paths are included in the publication.

