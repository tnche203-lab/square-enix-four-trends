# Four candidate findings

These are four options for the group's Square Enix consultancy report. The first three describe market patterns; the fourth describes change across release years. All findings are observational associations, not proof that a business decision would cause a particular sales increase.

## Quick list for the group

1. **Different genres have different regional sales patterns.** RPGs had a more Japan-oriented sales profile than shooters in the historical PlayStation sample. **Source:** teacher-provided VGChartz workbook, 398 game–platform records from 2000–2018. **Method:** multiple linear regression of the log Japan-to-North-America sales ratio, with a genre-by-console interaction.
2. **Broader language support is associated with higher Square Enix sales.** The relationship remained after accounting for major franchises. **Source:** teacher-provided Gamalytic/Steam workbook, 96 Square Enix titles first released in 2015–2025. **Method:** multiple linear regression, with franchise controls and checks excluding top sellers.
3. **RPG and simulation sales patterns extend beyond blockbusters.** Positive associations also appeared around the middle of the conditional sales distribution. **Source:** Gamalytic/Steam workbook, 90,770 paid-at-observation titles first released in 2015–2025. **Method:** multiple linear regression and median regression, plus a check excluding the top 1% of sellers.
4. **Casual games gained release share, but growth slowed.** Most of the increase occurred during 2015–2018, followed by smaller gains. **Source:** Gamalytic/Steam workbook, 107,101 titles first released in 2015–2025. **Method:** annual comparisons and exploratory piecewise logistic regression.

The original filenames, worksheets and checksums are documented in [data instructions](../data/README.md). The [methodology](methodology.md) explains the filtering, models and uncertainty. An [overview figure](../figures/four_trend_options.png) compares the four options.

## 1. Regional positioning: the genre difference varies by console

We compared RPGs and shooters with positive recorded sales in both Japan and North America. The regression controlled for release year, critic score and publisher and allowed the genre difference to vary across consoles.

| Console | Adjusted ratio multiplier: shooter relative to RPG | 95% confidence interval |
|---|---:|---:|
| PS2 | 0.079 | 0.043–0.147 |
| PS3 | **0.414** | **0.289–0.593** |
| PS4 | **0.464** | **0.318–0.678** |
| Xbox 360 | 0.702 | 0.445–1.107 |

For example, the model estimates that a shooter's Japan/NA sales ratio on PS3 was about 41% of the ratio for an RPG with the same control-variable values. This compares the two genres' regional sales profiles; it does not say that an RPG necessarily sold more copies in Japan than in North America.

The PS3 and PS4 multipliers remained below one, at **0.531 and 0.540**, after excluding records with fewer than 50,000 copies in either region to reduce sensitivity to rounding. The Xbox 360 estimate was inconclusive.

**Use for Square Enix:** evaluate regional positioning by genre and platform rather than relying only on worldwide genre rankings. **Boundary:** this is a selective historical sample, not evidence about all games, individual consumer preferences or current consoles.

[Detailed results](../results/regional/results.json)

## 2. Localisation: the association survives major-franchise controls

Among 96 Square Enix titles, a doubling of supported languages was associated with a **2.45-fold conditional geometric mean of sales plus one** after controlling for price, review score, release year and major genre tags.

| Specification | Titles | Multiplier for doubling language count | 95% confidence interval |
|---|---:|---:|---:|
| Basic controls | 96 | 2.45 | 2.00–2.99 |
| Add major-franchise controls | 96 | **2.36** | **1.79–3.10** |
| Franchise controls, excluding the highest-selling 5% | 91 | 2.09 | 1.67–2.61 |
| Franchise controls, excluding 2025 releases | 91 | 2.40 | 1.81–3.18 |

**Use for Square Enix:** make language coverage an explicit part of distribution planning, then assess individual languages against expected demand and localisation costs. **Boundary:** the model does not establish a causal return from adding languages. Budgets, expected popularity and post-success language updates may influence both language coverage and sales. The data cannot identify which countries account for the additional sales.

[Detailed results](../results/localization/results.json)

## 3. Genre opportunities: the pattern is also present at the median

The models controlled for price, language coverage, review score, release year, early-access status and overlapping genre tags.

| Adjusted sales-plus-one measure | RPG tag | Simulation tag |
|---|---:|---:|
| Conditional geometric mean multiplier | **1.548** | **1.850** |
| 95% CI, publisher-list clustered | 1.410–1.698 | 1.712–2.000 |
| Conditional median multiplier | **1.555** | **1.805** |
| Geometric mean multiplier after excluding the top 1% of sellers | 1.522 | 1.824 |

Each multiplier compares titles with a tag against those without that tag, holding the model's other variables constant. The median results and trimmed-sample check suggest that the associations are not explained solely by a handful of blockbusters.

**Use for Square Enix:** provide a PC-market reason to investigate RPG and simulation opportunities further. **Boundary:** these tags overlap, so this is not a direct ranking of two mutually exclusive categories. It does not show that adding simulation mechanics to an RPG increases sales. Development costs, profitability and project failure risk were not measured.

[Detailed results](../results/steam_genre/results.json)

## 4. Release composition: Casual rose early, then grew more slowly

The observed Casual share was **30.7% in the 2015 release cohort, 45.7% in 2018 and 48.0% in 2025**. An exploratory model allowed different slopes before and after 2018.

| Period | Model-fitted Casual share | Fitted change | 95% CI for change |
|---|---:|---:|---:|
| 2015–2018 | 32.8% → 44.8% | **+12.02 percentage points** | +9.31 to +14.73 |
| 2018–2025 | 44.8% → 47.5% | **+2.71 percentage points** | +0.55 to +4.86 |

The fitted shares differ from the raw observations above. A broader comparison of 2015–2019 against 2020–2025 also remained positive when restricted to paid titles or when Hobbyist-class publishers were excluded.

**Use for Square Enix:** assess competition and differentiation when considering a Casual offering. **Boundary:** this describes the composition of one observed catalogue by first-release year. It does not establish growing consumer demand, profitability or a historical census of every game available each year. The 2018 split was selected after inspecting the annual pattern and is exploratory.

[Detailed results](../results/temporal/temporal_results.json) · [Annual counts and shares](../results/temporal/annual_genre_composition.csv)

## Choosing three

Keep **2 and 3** if the report should emphasise sales and practical product/distribution decisions. Add **1** for a console and regional perspective, or **4** for a clear time trend and supply-side perspective. If another group member already covers regional analysis, **2 + 3 + 4** avoids repeating the same question.

The third teacher-provided workbook, *Mobile Games*, was not used for these four findings. Its selected high-revenue games are unsuitable for treating the sample as representative of the full mobile market.
