# Methodology and interpretation

This document describes the analysis behind the [four candidate findings](findings.md). It separates what was measured, how each model was fitted, and what its results can support. These are exploratory analyses for a consultancy report, not causal experiments or validated sales forecasts.

## Data and common decisions

Two teacher-provided workbooks were analysed:

| Source | Worksheet | Original rows | Used for |
|---|---|---:|---|
| `1 - PC Console VGCHARTZ Data 2024.xlsx` | `vgchartz-2024-ordered` | 64,016 | Regional sales profiles |
| `2 - PC Gamalytic Scraped.xlsx` | `GameAnalytics` | 121,942 | Localisation, genre associations and release composition |

Raw workbooks are not distributed in this repository. See [data instructions](../data/README.md) for placement and checksum information. Analysis reads the originals without modifying them. The results describe those supplied snapshots, not a live extract from either provider.

For the Steam analyses, a title had to be marked released, have a first-release year in **2015–2025**, and have at least one of ten common game tags: Action, Adventure, Casual, Indie, RPG, Racing, Simulation, Sports, Strategy or Massively Multiplayer. This excludes obvious non-game catalogue entries. Eligible records had no duplicate Steam IDs. Genre tags overlap and are represented by separate indicators.

The paid sales sample additionally required a positive observed price, no case-insensitive `Free to Play` tag and at least one supported language. This produced **90,770 titles**. “Paid” therefore refers to the observed snapshot, not every price charged throughout a game's life. The composition analysis includes free and paid titles and uses **107,101 titles**. Incomplete 2026 release cohorts were excluded.

Sales models use `ln(copiesSold + 1)`: sales are strongly skewed and adding one retains the six zero-sales titles in the large paid sample. Exponentiating an OLS coefficient describes a **conditional geometric-mean multiplier of sales plus one**, not an arithmetic-mean sales multiplier. For median regression, the monotonic transformation gives a **conditional median multiplier of sales plus one**. All reported confidence intervals are model-based and exclude errors in the provider's sales estimates and coverage.

## 1. Regional sales profiles

**Question:** does the Japan-to-North-America sales profile differ between RPGs and shooters, and does the difference vary by console?

### Selection and preparation

- Keep releases from 2000–2018 and the two selected genres.
- Exclude all rows with duplicated title–console keys rather than selecting an arbitrary duplicate.
- Require positive recorded sales in both regions; missing sales are not treated as zero.
- Require at least ten records from each genre on a console. PS2, PS3, PS4 and Xbox 360 meet this rule.

The final sample contains **398 game–platform records, 308 unique titles**, including 174 RPG and 224 shooter records. Of 6,516 nonduplicate two-genre records in the date window, only 635 had positive sales in both regions before the console-support restriction. This is an important selection limit.

The 164 missing critic scores were filled with the sample median, 7.8, and accompanied by a missing-score indicator. Publishers with at least ten records were represented individually; the remainder formed an Other category.

### Model and inference

```text
ln(Japan sales / North America sales)
    ~ Shooter * Console
    + Release-year categories
    + Critic score + Missing-score indicator
    + Publisher group
```

The `*` includes genre, console and their interaction. Standard errors are clustered by title, allowing records of the same game on different platforms to be related. A joint interaction test gave F(3,307) = 11.97, p < .001, so console-specific contrasts are reported rather than imposing one common genre difference. Holm adjustment was applied to the four console comparisons; the confidence intervals displayed in the findings are individual, not simultaneous, intervals.

Exponentiated contrasts compare the adjusted geometric means of the JP/NA ratio for shooters and RPGs. A multiplier below one indicates a relatively more North-America-oriented shooter profile. It does not measure an absolute sales decline or individual preferences.

### Checks

The interaction model was refitted after requiring at least 0.05 million copies in each region, reducing rounding sensitivity and leaving 184 records. Additional checks used only PS3/PS4 records or only records with observed scores. The PlayStation direction persisted. Missing regional coverage, unmeasured IP strength and budgets, and the historical sample limit generalisation.

[Results and model formulae](../results/regional/results.json)

## 2. Language coverage and Square Enix sales

**Question:** is the language–sales association visible within Square Enix, including after limited controls for major franchises?

The paid Steam sample was restricted to titles whose publisher field included Square Enix, leaving **96 titles**. Publisher ownership is taken from the course snapshot. Unique supported language names were counted; duplicate language-list entries were checked. The measure captures breadth, not translation quality or full-audio coverage.

### Model

```text
ln(copiesSold + 1)
    ~ log2(Language count) + log2(Observed price)
    + Review score / 10 + Linear release year
    + Action + Adventure + RPG
```

These three tags had sufficient presence and absence in the small company sample. A linear year term limits the number of parameters: eight in the baseline model, including the intercept. HC3 heteroskedasticity-robust standard errors were used. A one-unit increase in `log2(Language count)` corresponds to doubling the count.

A second model added four franchise groups, identified from title keywords: Final Fantasy (22), Dragon Quest (10), SaGa (8) and Other (56). This gave eleven parameters. The coding is a targeted check and does not capture every franchise or measure IP strength fully.

### Checks and scope

The franchise-adjusted model was refitted excluding 2025 releases and excluding the top 5% by sales; each left 91 titles. A further model excluded Final Fantasy and SaGa entirely, leaving 66. The positive association remained in all checks.

Language coverage, prices and reviews are observed after release. Successful games may receive later language updates, and budget, expected demand or marketing may influence both language count and sales. The coefficient must not be described as the causal sales gain from adding languages. No regional sales are available to identify which language or country drives the association.

The published finding relies on the company-specific models. Any earlier full-market localisation estimates retained in historical output are supporting provenance, not needed for this claim.

[Company model results](../results/localization/results.json)

## 3. Genre associations beyond blockbusters

**Question:** do RPG and simulation associations extend to the conditional median, and do they survive removal of the largest sellers?

The **90,770-title** paid sample contains 16,930 RPG-tagged titles and 20,147 simulation-tagged titles; 3,893 have both tags. Eight thousand and two titles have a zero review score. A zero-score indicator is used because the meaning of zero may differ from an ordinary low score.

OLS and median regression use the same predictors:

```text
ln(copiesSold + 1)
    ~ log2(Observed price) + log2(Language count)
    + Review score / 10 + Zero-score indicator
    + Early-access indicator + Release-year categories
    + Ten overlapping genre indicators
```

OLS inference is clustered by the identical publisher list, with **50,401 groups**. Empty publisher lists are grouped by individual Steam ID. This allows correlation within a recorded list, but does not identify every shared publisher across differently written or partly overlapping lists.

Median regression estimates the middle of the conditional distribution directly; it does not select a subset of “middle-selling” games. Its standard errors are heteroskedasticity-robust asymptotic estimates and **are not publisher-clustered**. Accordingly, the overview emphasises median point estimates and clustered OLS intervals. The median fit converged after 268 iterations without a convergence warning.

Benjamini–Hochberg adjustment across ten genre tests retained the RPG and simulation associations. OLS was repeated after removing the highest-selling 1% (89,862 titles retained) and after excluding zero-score titles (82,768 retained).

The combined checks address sensitivity to extreme sellers, but do not establish lower failure risk or higher profits. Separate tag coefficients are not a direct comparison of exclusive genres, and no RPG-by-Simulation interaction was tested. Release-year categories only partly account for differences in time available to accumulate sales.

[Model results and coefficients](../results/steam_genre/results.json)

## 4. Casual release composition over time

**Question:** how does the proportion of Casual-tagged titles vary across first-release cohorts?

This analysis includes **107,101 free and paid titles**. The outcome is current Casual-tag membership, grouped by `firstReleaseDate` year, including Early Access where that was the first release. It is not annual sales or demand.

Annual counts and shares were inspected before fitting a three-parameter binomial logistic model:

```text
logit[P(Casual)] = intercept
                  + b1 * min(year - 2015, 3)
                  + b2 * max(year - 2018, 0)
```

This continuous model permits separate slopes for 2015–2018 and 2018–2025. The **2018 split is exploratory**, selected after inspecting the annual pattern; the confidence intervals do not incorporate uncertainty from choosing that split. The annual odds ratios are 1.185 and 1.016 respectively. Predicted probabilities translate these into fitted changes of 12.02 and 2.71 percentage points. Odds ratios and percentage-point changes are different quantities.

Inference is clustered by the recorded publisher field, with **60,403 groups**; unknown publishers are individualised by Steam ID. For additional checks, a separate period model compares 2015–2019 with 2020–2025. The broader period difference remains when controlling for publisher class, retaining only paid titles, or excluding Hobbyist-class publishers. The ten-tag period screen used Benjamini–Hochberg adjustment. Publisher class is its snapshot classification, not a reliable measure of budget or publisher scale at release.

The source is one observed catalogue, not a succession of historical censuses. Delisting, incomplete coverage and changed tags can affect older cohorts. Tags overlap, so a rise in Casual share does not imply that Casual replaced RPG. The model cannot forecast future demand or demonstrate profitability.

[Model results](../results/temporal/temporal_results.json) · [Annual table](../results/temporal/annual_genre_composition.csv)

## Reproducibility and reporting

The [repository instructions](../README.md) describe how to run the scripts with the original course workbooks. Machine-readable outputs preserve exact estimates; tables in the findings round them for readability. A displayed `p = 0` in numerical output should be read as numerical underflow, not literal zero probability.

The four questions were selected through exploration and substantive relevance. Neither sensitivity checks nor multiple-comparison adjustments turn that process into a preregistered confirmatory study. Report the effect sizes, supporting checks and material limits together, and use the results to motivate further business evaluation rather than an automatic investment decision.
