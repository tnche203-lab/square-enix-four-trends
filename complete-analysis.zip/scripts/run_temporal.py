"""Read-only cohort composition analysis of the supplied Steam workbook.

No cumulative-sales-by-year analysis or demand inference is made here.
Install the dependencies in requirements.txt before running.
"""
from pathlib import Path
import ast, hashlib, json
from settings import DATA, FIGURES, output_dir, source_label
import numpy as np
import pandas as pd
import openpyxl
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from scipy.special import expit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=output_dir('temporal')
SOURCE=DATA/'2 - PC Gamalytic Scraped.xlsx'
TAGS=['Action','Adventure','Casual','Indie','RPG','Racing','Simulation','Sports','Strategy','Massively Multiplayer']
res={'source':source_label(SOURCE),'sheet':'GameAnalytics','sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
     'definitions':{'unit':'one unique Steam app ID with a common game genre tag',
       'time':'year of firstReleaseDate, including Early Access when this is first release',
       'population':'released games with firstReleaseDate in 2015-2025; free and paid included',
       'outcome':'current genre-tag membership, grouped by first-release cohort',
       'earlier_period':'2015-2019','later_period':'2020-2025',
       'uncertainty':'model-based 95% CIs clustered by the publisher field; no guarantee about source coverage'},
     'models':{},'sensitivity':{}}
wb=openpyxl.load_workbook(SOURCE,read_only=True,data_only=True)
it=wb['GameAnalytics'].iter_rows(values_only=True)
raw=pd.DataFrame(it,columns=next(it)).dropna(how='all')
wb.close()
res['raw_rows']=len(raw)
# Read the original workbook directly; no previously prepared cache is needed.
for col in ['firstReleaseDate','earlyAccessExitDate','EAReleaseDate','releaseDate']:
    raw[col]=pd.to_datetime(raw[col],errors='raise').astype('datetime64[ns]')
res['source_read']='Original workbook read directly; no cache used.'
def parse(x):
    try: return ast.literal_eval(x) if isinstance(x,str) else []
    except (SyntaxError,ValueError): return []
raw['year']=pd.to_datetime(raw.firstReleaseDate,errors='coerce').dt.year
raw['tags']=raw.genres.map(parse)
raw['is_game']=raw.tags.map(lambda x:bool(set(TAGS).intersection(x)))
s=raw[(raw.unreleased==False)&raw.is_game&raw.year.between(2015,2025)].copy()
res['eligible_before_dedup']=len(s)
res['duplicate_steam_ids']=int(s.duplicated('steamId').sum())
s=s.drop_duplicates('steamId').copy()
assert s.steamId.notna().all()
s['year']=s.year.astype(int)
s['year_c']=s.year-2015
s['late']=(s.year>=2020).astype(int)
s['publisher_cluster']=s.publishers.fillna('[]').astype(str)
missing=s.publisher_cluster.eq('[]')|s.publisher_cluster.eq('')
s.loc[missing,'publisher_cluster']='unknown_app_'+s.loc[missing,'steamId'].astype(str)
res['publisher_clusters']=s.publisher_cluster.nunique()
res['unknown_publishers_individualized']=int(missing.sum())
for tag in TAGS: s['g_'+tag.replace(' ','_')]=s.tags.map(lambda x:int(tag in x))
res['n']=len(s)
res['publisher_classes']=s.publisherClass.value_counts().to_dict()
annual=s.groupby('year').agg(n=('steamId','size'))
for tag in TAGS:
    col='g_'+tag.replace(' ','_')
    annual[tag+'_n']=s.groupby('year')[col].sum()
    annual[tag+'_share']=s.groupby('year')[col].mean()
annual.to_csv(OUT/'annual_genre_composition.csv')
res['annual']=annual.reset_index().to_dict('records')
res['periods']=[]
for late,d in s.groupby('late'):
    res['periods'].append({'period':'2020-2025' if late else '2015-2019','n':len(d),
      'counts':{tag:int(d['g_'+tag.replace(' ','_')].sum()) for tag in TAGS},
      'shares':{tag:float(d['g_'+tag.replace(' ','_')].mean()) for tag in TAGS}})

def fit(tag,d,formula='late',name=None):
    col='g_'+tag.replace(' ','_')
    model=smf.glm(col+' ~ '+formula,d,family=sm.families.Binomial()).fit(
        cov_type='cluster',cov_kwds={'groups':d.publisher_cluster})
    term='late' if 'late' in formula else 'year_c'
    ci=model.conf_int().loc[term]
    out={'n':len(d),'formula':col+' ~ '+formula,'term':term,
         'beta':float(model.params[term]),'se':float(model.bse[term]),
         'odds_ratio':float(np.exp(model.params[term])),
         'or_ci':[float(np.exp(ci[0])),float(np.exp(ci[1]))],
         'p':float(model.pvalues[term]),'covariance':'publisher-cluster robust'}
    if formula=='late':
        b=model.params.to_numpy();V=model.cov_params().to_numpy()
        p0,p1=expit(b[0]),expit(b[0]+b[1])
        grad=np.array([p1*(1-p1)-p0*(1-p0),p1*(1-p1)])
        se=np.sqrt(grad@V@grad)
        out.update({'early_share':float(p0),'late_share':float(p1),'pp_difference':100*float(p1-p0),
                    'pp_difference_ci':[100*float(p1-p0-1.96*se),100*float(p1-p0+1.96*se)]})
    if name:
        (OUT/f'{name}.txt').write_text(model.summary().as_text())
    return out

# Exploratory family of all ten prespecified common game tags.
for tag in TAGS:
    res['models'][tag]=fit(tag,s)
q=multipletests([res['models'][t]['p'] for t in TAGS],method='fdr_bh')[1]
for tag,z in zip(TAGS,q):res['models'][tag]['q_bh_10_genres']=float(z)

# Context-selected tags, not a search for the smallest p-value.
for tag in ['Casual','Action','Simulation','RPG']:
    res['sensitivity'][tag]={
      'publisher_class_adjusted_period':fit(tag,s,'late + C(publisherClass)'),
      'paid_without_free_tag':fit(tag,s[s.price.gt(0)&~s.tags.map(lambda x:any(t.lower()=='free to play' for t in x))]),
      'excluding_hobbyist_class':fit(tag,s[s.publisherClass.ne('Hobbyist')]),
      'linear_log_odds_year':fit(tag,s,'year_c'),
      '2018_2025_linear_log_odds_year':fit(tag,s[s.year>=2018],'year_c'),
      '2020_2025_linear_log_odds_year':fit(tag,s[s.year>=2020],'year_c')}

# Shape check: one exploratory knot at 2018 chosen after viewing annual shares.
# This summarizes the observed slowdown, not a formally discovered breakpoint.
s['early_slope']=np.minimum(s.year-2015,3)
s['later_slope']=np.maximum(s.year-2018,0)
piece=smf.glm('g_Casual ~ early_slope + later_slope',s,family=sm.families.Binomial()).fit(
    cov_type='cluster',cov_kwds={'groups':s.publisher_cluster})
b=piece.params.to_numpy();V=piece.cov_params().to_numpy()
piece_result={'formula':'logit(P(Casual tag)) = intercept + b1*min(year-2015,3) + b2*max(year-2018,0)',
              'knot':'2018, exploratory visual choice; not a confirmed structural breakpoint',
              'annual_slopes':{},'predicted_shares':{},'predicted_pp_changes':{}}
for term in ['early_slope','later_slope']:
    lo,hi=piece.conf_int().loc[term]
    piece_result['annual_slopes'][term]={'beta':float(piece.params[term]),'or':float(np.exp(piece.params[term])),
         'or_ci':[float(np.exp(lo)),float(np.exp(hi))],'p':float(piece.pvalues[term])}
design={2015:np.array([1,0,0]),2018:np.array([1,3,0]),2025:np.array([1,3,7])}
for y,x in design.items():
    eta=x@b;se=np.sqrt(x@V@x)
    piece_result['predicted_shares'][y]={'share':float(expit(eta)),'ci':[float(expit(eta-1.96*se)),float(expit(eta+1.96*se))]}
for a,z in [(2015,2018),(2018,2025)]:
    xa,xz=design[a],design[z];pa,pz=expit(xa@b),expit(xz@b)
    grad=pz*(1-pz)*xz-pa*(1-pa)*xa;se=np.sqrt(grad@V@grad)
    piece_result['predicted_pp_changes'][f'{a}-{z}']={'pp':float(100*(pz-pa)),
        'ci':[float(100*(pz-pa-1.96*se)),float(100*(pz-pa+1.96*se))]}
piece_result['slope_difference_p']=float(piece.wald_test('early_slope = later_slope',scalar=True).pvalue)
res['casual_piecewise_shape']=piece_result
(OUT/'casual_piecewise_summary.txt').write_text(piece.summary().as_text())

# A visually assessed annual pattern is required before claiming monotonic change.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(9.5,5.6))
for tag,color in [('Casual','#2563eb'),('Action','#c46b22'),('Simulation','#1b8a5a'),('RPG','#8b5ca6')]:
    ax.plot(annual.index,100*annual[tag+'_share'],marker='o',lw=2,label=tag,color=color)
ax.set(xlabel='Year of first release (including Early Access)',ylabel='Share of first-release cohort (%)',
       title='Steam release cohorts shifted towards Casual games')
ax.set_xticks(range(2015,2026));ax.set_ylim(10,52);ax.grid(axis='y',alpha=.18)
ax.legend(ncol=4,loc='lower center',bbox_to_anchor=(.5,-.26),frameon=False)
fig.text(.02,.015,'Source: supplied Gamalytic workbook; released game apps, 2015–2025, N = 107,101.\nGenre tags overlap. These are supply-composition shares, not sales or demand shares.',fontsize=8.5)
fig.tight_layout(rect=[0,.085,1,1])
fig.savefig(FIGURES/'steam_cohort_composition.png',dpi=180)
fig.savefig(FIGURES/'steam_cohort_composition.pdf')
plt.close(fig)
(OUT/'temporal_results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({'n':res['n'],'models':{t:res['models'][t] for t in ['Casual','Action','Simulation','RPG']},
 'sensitivity':res['sensitivity']},indent=2))
