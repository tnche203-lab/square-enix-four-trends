"""Reproduce the Square Enix localization models directly from the source workbook.

The older, separate market-background models are intentionally not imported.
Row-level square_enix_audit.csv is a local-only output and must not be committed.
"""
from pathlib import Path
import json, hashlib, ast, re
import numpy as np, pandas as pd, statsmodels.formula.api as smf
from scipy.stats import spearmanr
import openpyxl

from settings import DATA, output_dir, source_label
OUT=output_dir('localization')
SOURCE=DATA/'2 - PC Gamalytic Scraped.xlsx'
sha=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert sha=='100920b8ea8e4662d39dac1f19e55756b2d3a7b6110ed8b85f1a865730c4999f', 'Source differs from original analysis.'
w=openpyxl.load_workbook(SOURCE,read_only=True,data_only=True)
it=w['GameAnalytics'].iter_rows(values_only=True);head=next(it)
d=pd.DataFrame(it,columns=head).dropna(how='all')
w.close()
def parse(x): return ast.literal_eval(x) if isinstance(x,str) else []
d['genre_list']=d.genres.map(parse);d['lang_list']=d.languages.map(parse)
d['nlang']=d.lang_list.map(lambda x:len(set(x)))
assert (d.nlang==d.lang_list.str.len()).all(),'duplicate language entries require audit'
d['year']=pd.to_datetime(d.firstReleaseDate,format='mixed',errors='coerce').dt.year
game_tags={'Action','Adventure','Casual','Indie','RPG','Racing','Simulation','Sports','Strategy','Massively Multiplayer'}
d=d[(d.unreleased==False)&d.genre_list.map(lambda x:bool(game_tags.intersection(x)))].drop_duplicates('steamId')
d=d[d.year.between(2015,2025)&d.price.gt(0)&d.nlang.gt(0)&~d.genre_list.map(lambda x:any(t.lower()=='free to play' for t in x))].copy()
assert len(d)==90770
for tag in sorted(game_tags):d['g_'+tag.lower().replace(' ','_')]=d.genre_list.map(lambda x:int(tag in x))
d['log_sales']=np.log1p(d.copiesSold);d['log2_languages']=np.log2(d.nlang);d['log2_price']=np.log2(d.price)
d['review10']=d.reviewScore/10;d['year_c']=d.year-2020
se=d[d.publishers.str.contains('Square Enix',case=False)].copy()
assert len(se)==96
gcols=[c for c in d if c.startswith('g_')]
secols=[c for c in gcols if se[c].sum()>=15 and (1-se[c]).sum()>=15]
base='log_sales ~ log2_languages + log2_price + review10 + year_c + '+' + '.join(secols)

def franchise(n):
    n=n.upper()
    if 'FINAL FANTASY' in n or 'FFXV' in n: return 'Final Fantasy'
    if 'SAGA' in n: return 'SaGa'
    if 'DRAGON QUEST' in n: return 'Dragon Quest'
    return 'Other'
se['franchise']=se.name.map(franchise)
result={'source':source_label(SOURCE),'sha256':sha,'market_n':len(d),'se_n':len(se),'se_franchise_counts':se.franchise.value_counts().to_dict(),'checks':{}}

def fit(name,formula,data):
    model=smf.ols(formula,data,missing='raise').fit(cov_type='HC3',use_t=True)
    x=model.model.exog;assert np.linalg.matrix_rank(x)==x.shape[1]
    ci=model.conf_int().loc['log2_languages'];b=model.params['log2_languages']
    out={'n':int(model.nobs),'parameters':x.shape[1],'r2':float(model.rsquared),'beta':float(b),'p':float(model.pvalues['log2_languages']),
        'beta_ci':ci.tolist(),'multiplier':float(np.exp(b)),'multiplier_ci':np.exp(ci).tolist(),'formula':formula}
    result['checks'][name]=out
    (OUT/(name+'_summary.txt')).write_text(model.summary().as_text())
    return model

fit('se_baseline',base,se)
fit('se_franchise_control',base+' + C(franchise)',se)
fit('se_excluding_2025',base+' + C(franchise)',se[se.year.le(2024)])
fit('se_trim_top5pct',base+' + C(franchise)',se[se.copiesSold.le(se.copiesSold.quantile(.95))])
fit('se_without_ff_saga',base,se[~se.franchise.isin(['Final Fantasy','SaGa'])])

# A partial Spearman-style check is not substituted for regression; show descriptive ranks.
rho,p=spearmanr(se.nlang,se.copiesSold)
result['se_spearman']={'rho':float(rho),'p':float(p)}
se[['steamId','name','year','nlang','copiesSold','price','reviewScore','franchise']].to_csv(OUT/'square_enix_audit.csv',index=False)
(OUT/'results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(result['checks'],indent=2,ensure_ascii=False))
