"""Historical genre/region association, read-only source workbooks.

Run with numpy, pandas, openpyxl and statsmodels. The main comparison is fixed
in advance as RPG versus Shooter; the platform support rule requires >= 10
observations of both genres on a console. No outcome-based model selection.
"""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd
import statsmodels
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

from settings import DATA, output_dir, source_label
OUT = output_dir("regional")
SOURCE = DATA / "1 - PC Console VGCHARTZ Data 2024.xlsx"
EXPECTED_SHA = "c1a378b0fb95e168a02b4195ec9d867dae92ec9c592ea55b9d63c5484d9d6e1b"
actual_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert actual_sha == EXPECTED_SHA, "Source has changed: reconsider source audit."
d = pd.read_excel(SOURCE, sheet_name="vgchartz-2024-ordered")
results = {
    "source": {"path": source_label(SOURCE), "sheet": "vgchartz-2024-ordered", "sha256": actual_sha,
               "original_rows": len(d), "units": "sales in millions of copies"},
    "versions": {"numpy": np.__version__, "pandas": pd.__version__, "statsmodels": statsmodels.__version__},
    "design": {"comparison": "Role-Playing vs Shooter, specified from prior substantive question",
               "population": "historical game-platform records with positive recorded Japan and North America sales",
               "date_window": "release year 2000-2018 inclusive",
               "console_support_rule": ">=10 RPG and >=10 Shooter positive-both-region records",
               "outcome": "natural log of Japanese sales / North American sales for the SAME game-platform record",
               "inference": "OLS with title-clustered standard errors, t reference distribution"},
    "audit": {}, "models": {}}

d["year"] = pd.to_datetime(d.release_date, format="mixed", errors="coerce").dt.year
d = d.loc[d.year.between(2000, 2018)].copy()
results["audit"]["date_window_n"] = len(d)
dup = d.duplicated(["title", "console"], keep=False)
results["audit"]["duplicate_key_rows_excluded"] = int(dup.sum())
d = d.loc[~dup & d.genre.isin(["Role-Playing", "Shooter"])].copy()
results["audit"]["two_genre_before_regional_availability_n"] = len(d)
results["audit"]["missing_or_nonpositive_regional_rows_excluded"] = int((~(d.na_sales.gt(0) & d.jp_sales.gt(0))).sum())
d = d.loc[d.na_sales.gt(0) & d.jp_sales.gt(0)].copy()
support = pd.crosstab(d.console, d.genre)
support.to_csv(OUT / "console_support.csv")
consoles = support.index[support.ge(10).all(axis=1)].tolist()
assert consoles == ["PS2", "PS3", "PS4", "X360"]
results["audit"]["two_genre_regional_available_n"] = len(d)
d = d.loc[d.console.isin(consoles)].copy()
d["year"] = d.year.astype(int)
d["log_jp_na"] = np.log(d.jp_sales / d.na_sales)
d["shooter"] = d.genre.eq("Shooter").astype(int)
d["score_missing"] = d.critic_score.isna().astype(int)
d["score"] = d.critic_score.fillna(d.critic_score.median())
# Keep adequately represented publishers; group the rest. The grouping is fixed
# from the main sample and reused without regrouping for sensitivity analyses.
pub_counts = d.publisher.value_counts()
d["publisher_group"] = d.publisher.where(d.publisher.map(pub_counts).ge(10), "Other")
results["audit"].update({"analysis_n": len(d), "unique_titles": d.title.nunique(),
                         "observed_years": [int(d.year.min()), int(d.year.max())],
                         "score_missing_n": int(d.score_missing.sum()),
                         "score_fill_median": float(d.critic_score.median()),
                         "genre_counts": {k: int(v) for k, v in d.genre.value_counts().items()},
                         "console_genre_counts": pd.crosstab(d.console, d.genre).to_dict()})

def contrast_record(r, vector):
    t = r.t_test(vector)
    estimate = float(np.asarray(t.effect).ravel()[0])
    ci = np.asarray(t.conf_int()).ravel()
    return {"log_coefficient": estimate, "multiplier": float(np.exp(estimate)),
            "multiplier_ci95": np.exp(ci).tolist(), "p": float(np.asarray(t.pvalue).ravel()[0])}

def fit(label, data, formula):
    model = smf.ols(formula, data=data, missing="raise")
    assert np.linalg.matrix_rank(model.exog) == model.exog.shape[1]
    r = model.fit(cov_type="cluster", cov_kwds={"groups": data.title}, use_t=True)
    assert int(r.nobs) == len(data)
    # Verify solver output independently and retain a row-level analysis audit.
    independent = np.linalg.lstsq(model.exog, model.endog, rcond=None)[0]
    assert np.max(np.abs(model.exog @ independent - r.fittedvalues)) < 1e-8
    rec = {"n": len(data), "clusters": int(data.title.nunique()), "parameters": len(r.params),
           "r2": float(r.rsquared), "adjusted_r2": float(r.rsquared_adj), "formula": formula,
           "genre_counts": {k: int(v) for k, v in data.genre.value_counts().items()}}
    if "*" not in formula:
        vector = np.zeros(len(r.params)); vector[r.params.index.get_loc("shooter")] = 1
        rec["shooter_vs_rpg"] = contrast_record(r, vector)
    ci = r.conf_int()
    tab = pd.DataFrame({"term": r.params.index, "coefficient": r.params.values,
                        "std_error": r.bse.values, "ci_low": ci[0].values, "ci_high": ci[1].values,
                        "p": r.pvalues.values})
    tab.to_csv(OUT / f"{label}_coefficients.csv", index=False)
    # Report the relevant coefficient inference, not the irrelevant all-terms F
    # test (whose clustered covariance can be singular with sparse fixed effects).
    (OUT / f"{label}_summary.txt").write_text(json.dumps(rec, indent=2) + "\n\n" + tab.to_string(index=False))
    results["models"][label] = rec
    return r

controls = "C(console) + C(year) + score + score_missing"
main_formula = "log_jp_na ~ shooter + " + controls + " + C(publisher_group)"
fit("without_publisher", d, "log_jp_na ~ shooter + " + controls)
fit("main", d, main_formula)
# Precision check: source has 0.01-million reporting increments. Values below
# 0.05 million are especially sensitive to such rounding, on either side.
large = d.loc[d.na_sales.ge(.05) & d.jp_sales.ge(.05)].copy()
fit("rounding_check", large, main_formula)
# Check that filling missing critics scores is not driving the genre finding.
scored = d.loc[d.critic_score.notna()].copy()
fit("observed_scores_only", scored, main_formula.replace(" + score_missing", ""))

# Test the pooled model's assumption of a common genre contrast across consoles.
# This is a diagnostic, reported whether significant or not; do not mine pairs.
interaction_formula = "log_jp_na ~ shooter * C(console) + C(year) + score + score_missing + C(publisher_group)"
for label, data in [("console_interaction", d), ("rounding_console_interaction", large)]:
    r = fit(label, data, interaction_formula)
    idx = [i for i, term in enumerate(r.params.index) if "shooter:" in term]
    joint = r.f_test(np.eye(len(r.params))[idx])
    irec = results["models"][label]
    irec["interaction_joint_test"] = {"F": float(joint.fvalue), "p": float(joint.pvalue),
                                      "df_numerator": int(joint.df_num), "df_denominator": int(joint.df_denom)}
    irec["console_genre_counts"] = pd.crosstab(data.console, data.genre).to_dict()
    irec["contrasts_by_console"] = {}
    for console in consoles:
        vec = np.zeros(len(r.params))
        vec[r.params.index.get_loc("shooter")] = 1
        if console != "PS2":
            vec[r.params.index.get_loc(f"shooter:C(console)[T.{console}]")] = 1
        irec["contrasts_by_console"][console] = contrast_record(r, vec)
    ps = [irec["contrasts_by_console"][console]["p"] for console in consoles]
    adjusted_ps = multipletests(ps, method="holm")[1]
    for console, p_adj in zip(consoles, adjusted_ps):
        irec["contrasts_by_console"][console]["p_holm_four_console_comparisons"] = float(p_adj)

# Explicit, limited follow-up to the interaction diagnostic: remove the oldest
# console and compare the two well-represented newer PlayStation generations.
# This robustness check does not replace the original four-console analysis.
modern_sony = d.loc[d.console.isin(["PS3", "PS4"])].copy()
fit("ps3_ps4_only", modern_sony, main_formula)

descriptive = d.groupby("genre").agg(records=("title", "size"), unique_titles=("title", "nunique"),
                                       log_ratio_mean=("log_jp_na", "mean"), log_ratio_median=("log_jp_na", "median"))
descriptive["geometric_mean_jp_na_ratio"] = np.exp(descriptive.log_ratio_mean)
descriptive["median_jp_na_ratio"] = np.exp(descriptive.log_ratio_median)
results["descriptive"] = descriptive.to_dict("index")
descriptive.to_csv(OUT / "descriptive.csv")
d[["title", "console", "genre", "year", "publisher", "publisher_group", "critic_score", "score",
   "score_missing", "na_sales", "jp_sales", "log_jp_na"]].to_csv(OUT / "sample_audit.csv", index=False)
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == actual_sha
(OUT / "results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
print(json.dumps(results, ensure_ascii=False, indent=2))
