"""Run all four analyses, then produce figures (never downloads source data)."""
from pathlib import Path
import subprocess
import sys
from settings import DATA

required = ["1 - PC Console VGCHARTZ Data 2024.xlsx", "2 - PC Gamalytic Scraped.xlsx"]
missing = [name for name in required if not (DATA / name).is_file()]
if missing:
    raise SystemExit("Place the original course workbooks in data/ before running:\n" + "\n".join(missing))
for name in ["run_regional.py", "analyze_localization.py", "analyse_steam_genre.py", "run_temporal.py", "make_overview.py"]:
    print(f"Running {name}", flush=True)
    subprocess.run([sys.executable, str(Path(__file__).parent / name)], check=True)
print("Complete. Aggregated results: results/. Figures: figures/.", flush=True)
