"""Render the four independently verified candidate findings from saved results."""
from pathlib import Path
import json
from settings import RESULTS, FIGURES
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

P=RESULTS
read=lambda p:json.loads((P/p).read_text())
r=read('regional/results.json');l=read('localization/results.json')
g=read('steam_genre/results.json');t=read('temporal/temporal_results.json')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
 'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold'})
blue='#245f93';orange='#bd6c27';gray='#76838d'
fig,axs=plt.subplots(2,2,figsize=(13.2,9.3))
fig.subplots_adjust(left=.17,right=.97,bottom=.15,top=.90,wspace=.58,hspace=.58)

ax=axs[0,0]
for i,name in enumerate(['PS2','PS3','PS4','X360']):
 z=r['models']['console_interaction']['contrasts_by_console'][name]
 b=z['multiplier'];lo,hi=z['multiplier_ci95']
 ax.errorbar(b,i,xerr=[[b-lo],[hi-b]],fmt='o',capsize=4,color=blue if name!='X360' else gray)
ax.set_yticks(range(4),['PS2','PS3','PS4','Xbox 360']);ax.invert_yaxis()
ax.axvline(1,color=gray,ls='--',lw=1);ax.set_xlim(0,1.2)
ax.set_title('1  Regional sales profiles\n398 game-platform records',loc='left',fontsize=12)
ax.set_xlabel('Shooter / RPG multiplier of the Japan-to-NA ratio')
ax.grid(axis='x',alpha=.15)

ax=axs[0,1]
for i,(key,label) in enumerate([('se_baseline','Basic controls'),('se_franchise_control','+ Major franchises'),('se_trim_top5pct','+ Franchises, no top 5%')]):
 z=l['checks'][key];b=z['multiplier'];lo,hi=z['multiplier_ci']
 ax.errorbar(b,i,xerr=[[b-lo],[hi-b]],fmt='o',capsize=4,color=blue)
ax.set_yticks(range(3),['Basic controls','+ Major franchises','+ Franchises, no top 5%']);ax.invert_yaxis()
ax.axvline(1,color=gray,ls='--',lw=1);ax.set_xlim(.9,3.3)
ax.set_title('2  Language breadth and Square Enix sales\n96 paid-at-observation Steam titles',loc='left',fontsize=12)
ax.set_xlabel('Languages doubled: adjusted multiplier of sales + 1')
ax.grid(axis='x',alpha=.15)

ax=axs[1,0]
for i,tag in enumerate(['g_rpg','g_simulation']):
 a=next(z for z in g['models']['ols_publisher_cluster']['coefficients'] if z['term']==tag)
 b=next(z for z in g['models']['median_main']['coefficients'] if z['term']==tag)
 x=a['multiplier'];lo=a['multiplier_ci_low'];hi=a['multiplier_ci_high']
 ax.errorbar(x,i-.10,xerr=[[x-lo],[hi-x]],fmt='o',capsize=4,color=blue)
 # Median regression is shown as a point-only corroborating estimate: its
 # available interval is not publisher-clustered like the OLS interval.
 ax.plot(b['multiplier'],i+.10,'s',color=orange)
ax.set_yticks([0,1],['RPG tag','Simulation tag']);ax.invert_yaxis()
ax.set_ylim(1.45,-.5);ax.set_xlim(.95,2.08);ax.axvline(1,color=gray,ls='--',lw=1)
ax.set_title('3  Genre association reaches the median\n90,770 paid-at-observation Steam titles',loc='left',fontsize=12)
ax.set_xlabel('Adjusted multiplier of sales + 1')
ax.plot([],[],marker='o',ls='',color=blue,label='OLS geometric mean (95% CI)')
ax.plot([],[],marker='s',ls='',color=orange,label='Conditional median (point estimate)')
ax.legend(loc='lower left',fontsize=8,frameon=False);ax.grid(axis='x',alpha=.15)

ax=axs[1,1]
annual=t['annual'];years=np.array([a['year'] for a in annual]);shares=np.array([a['Casual_share'] for a in annual])*100
ax.plot(years,shares,'o-',color=blue,lw=2,label='Observed cohort share')
z=t['casual_piecewise_shape'];pred=z['predicted_shares'];b1=z['annual_slopes']['early_slope']['beta'];b2=z['annual_slopes']['later_slope']['beta']
start=pred['2015']['share'];intercept=np.log(start/(1-start));grid=np.linspace(2015,2025,201)
eta=intercept+b1*np.minimum(grid-2015,3)+b2*np.maximum(grid-2018,0)
ax.plot(grid,100/(1+np.exp(-eta)),color=orange,ls='--',lw=1.6,label='Exploratory piecewise logistic')
ax.axvline(2018,color=gray,ls=':',lw=1)
for year,offset in [(2015,(8,-12)),(2018,(3,9)),(2025,(-35,9))]:
 val=shares[np.where(years==year)[0][0]]
 ax.annotate(f'{val:.1f}%',(year,val),xytext=offset,textcoords='offset points',fontsize=9)
ax.set_ylim(26,53);ax.set_xticks([2015,2018,2021,2025]);ax.yaxis.set_major_formatter(FuncFormatter(lambda y,p:f'{y:.0f}%'))
ax.set_title('4  Casual share rose, then grew more slowly\n107,101 Steam first-release cohort records',loc='left',fontsize=12)
ax.set_xlabel('First-release year');ax.set_ylabel('Share with Casual tag')
ax.legend(loc='lower right',fontsize=8,frameon=False);ax.grid(axis='y',alpha=.15)

fig.suptitle('Four evidence-based options for the Square Enix report',fontsize=17,x=.17,ha='left')
fig.text(.17,.045,'Bars: 95% confidence intervals. Observational associations, not causal effects or profit forecasts.\nPanels 1-3 describe conditional market patterns; panel 4 describes the composition of release cohorts in one catalogue snapshot.',fontsize=9,color='#44515b')
fig.savefig(FIGURES/'four_trend_options.png',dpi=180)
fig.savefig(FIGURES/'four_trend_options.pdf')
plt.close(fig)
