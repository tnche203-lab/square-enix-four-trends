"""Portable repository paths; source workbooks and audit rows remain local."""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
CACHE = ROOT / ".cache"
os.environ.setdefault("MPLCONFIGDIR", str(CACHE / "matplotlib"))
FIGURES.mkdir(parents=True, exist_ok=True)

def output_dir(name):
    path = RESULTS / name
    path.mkdir(parents=True, exist_ok=True)
    return path

def source_label(path):
    return path.relative_to(ROOT).as_posix()
