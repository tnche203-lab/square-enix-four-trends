"""Steam genre associations: OLS plus conditional-median regression.

Read-only source workbook. No causal effects or profit forecasts are estimated.
Install the dependencies in requirements.txt before running.
"""
from pathlib import Path
import ast
import hashlib
import json
import time
import warnings
import numpy as np
import pandas as pd
import openpyxl
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

from settings import DATA, output_dir, source_label
OUT = output_dir('steam_genre')
SOURCE = DATA / '2 - PC Gamalytic Scraped.xlsx'
SHEET = 'GameAnalytics'
GAME_TAGS = ['Action', 'Adventure', 'Casual', 'Indie', 'RPG', 'Racing',
             'Simulation', 'Sports', 'Strategy', 'Massively Multiplayer']
RESULT = {'source': {'path': source_label(SOURCE), 'sheet': SHEET,
                    'sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest()},
          'models': {}, 'checks': {}}

def parse_list(x):
    parsed = ast.literal_eval(x) if isinstance(x, str) else x
    assert isinstance(parsed, list)
    return parsed

w = openpyxl.load_workbook(SOURCE, read_only=True, data_only=True)
it = w[SHEET].iter_rows(values_only=True)
header = next(it)
s = pd.DataFrame(it, columns=header).dropna(how='all')
w.close()
RESULT['source']['raw_rows'] = len(s)
RESULT['checks']['duplicate_steam_ids'] = int(s.steamId.duplicated().sum())
assert not s.steamId.duplicated().any()
s['year'] = pd.to_datetime(s.firstReleaseDate, format='mixed', errors='raise').dt.year
s['genre_list'] = s.genres.map(parse_list)
s['lang_list'] = s.languages.map(parse_list)
s['n_languages'] = s.lang_list.str.len()
filters = [('released', s.unreleased.eq(False)),
           ('has_game_genre', s.genre_list.map(lambda x: bool(set(GAME_TAGS).intersection(x)))),
           ('release_2015_2025', s.year.between(2015, 2025)),
           ('price_positive', s.price.gt(0)),
           ('languages_positive', s.n_languages.gt(0)),
           ('not_free_tag', ~s.genre_list.map(lambda x: any(t.lower() == 'free to play' for t in x)))]
keep = pd.Series(True, index=s.index)
flow = []
for label, flag in filters:
    before = int(keep.sum())
    keep &= flag
    flow.append({'filter': label, 'remaining': int(keep.sum()), 'excluded': before-int(keep.sum())})
s = s.loc[keep].copy()
RESULT['checks']['sample_flow'] = flow
s['log_sales'] = np.log1p(s.copiesSold)
s['log2_price'] = np.log2(s.price)
s['log2_languages'] = np.log2(s.n_languages)
s['review10'] = s.reviewScore / 10
s['zero_review'] = s.reviewScore.eq(0).astype(int)
s['early_access'] = s.earlyAccess.astype(int)
s['publisher_cluster'] = s.publishers.where(s.publishers.ne('[]'), 'unknown_' + s.steamId.astype(str))
for g in GAME_TAGS:
    s['g_' + g.lower().replace(' ', '_')] = s.genre_list.map(lambda x: int(g in x))
genre_cols = ['g_' + g.lower().replace(' ', '_') for g in GAME_TAGS]
formula = 'log_sales ~ log2_price + log2_languages + review10 + zero_review + early_access + C(year) + ' + ' + '.join(genre_cols)
RESULT['formula'] = formula
RESULT['sample'] = {'n': len(s), 'year_range': [int(s.year.min()), int(s.year.max())],
                    'zero_copies': int(s.copiesSold.eq(0).sum()),
                    'zero_review': int(s.zero_review.sum()),
                    'unique_publisher_lists': int(s.publisher_cluster.nunique()),
                    'copies_median': float(s.copiesSold.median()),
                    'tag_counts': {g: int(s['g_' + g.lower().replace(' ', '_')].sum()) for g in GAME_TAGS},
                    'rpg_simulation_both': int((s.g_rpg.eq(1) & s.g_simulation.eq(1)).sum())}
s[['steamId','name','year','copiesSold','price','reviewScore','n_languages']+genre_cols].to_csv(OUT/'sample_audit.csv', index=False)

def record(name, res, frame, method, warning_text=None):
    ci = res.conf_int()
    rows = []
    for term in res.params.index:
        rows.append({'term': term, 'coefficient': float(res.params[term]),
                     'ci_low': float(ci.loc[term, 0]), 'ci_high': float(ci.loc[term, 1]),
                     'p': float(res.pvalues[term]), 'multiplier': float(np.exp(res.params[term])),
                     'multiplier_ci_low': float(np.exp(ci.loc[term,0])),
                     'multiplier_ci_high': float(np.exp(ci.loc[term,1]))})
    genre_rows = [r for r in rows if r['term'].startswith('g_')]
    for row,q in zip(genre_rows, multipletests([r['p'] for r in genre_rows], method='fdr_bh')[1]):
        row['genre_q_bh'] = float(q)
    info = {'n': int(res.nobs), 'parameters': len(res.params), 'method': method,
            'formula': formula, 'coefficients': rows}
    if hasattr(res, 'prsquared'): info['pseudo_r2'] = float(res.prsquared)
    else: info['r2'] = float(res.rsquared)
    if hasattr(res, 'iterations'): info['iterations'] = int(res.iterations)
    if warning_text: info['warnings'] = warning_text
    RESULT['models'][name] = info
    pd.DataFrame(rows).to_csv(OUT/f'{name}_coefficients.csv', index=False)
    (OUT/f'{name}_summary.txt').write_text(res.summary().as_text())
    (OUT/'results.json').write_text(json.dumps(RESULT, indent=2, ensure_ascii=False, allow_nan=False))
    print(name, 'n=', len(frame), [(r['term'], round(r['multiplier'], 3), r['p']) for r in rows if r['term'] in ['g_rpg','g_simulation']], flush=True)

def ols(name, frame, cluster=False, model_formula=formula):
    model = smf.ols(model_formula, frame, missing='raise')
    assert np.linalg.matrix_rank(model.exog) == model.exog.shape[1]
    if cluster:
        fit = model.fit(cov_type='cluster', cov_kwds={'groups':frame.publisher_cluster}, use_t=True)
        method = 'OLS, publisher-list clustered standard errors'
    else:
        fit = model.fit(cov_type='HC3', use_t=True)
        method = 'OLS, HC3 robust standard errors'
    assert int(fit.nobs) == len(frame)
    record(name, fit, frame, method)
    RESULT['models'][name]['formula'] = model_formula
    return fit

start = time.time()
print('Read original workbook; sample',len(s),'elapsed',round(time.time()-start,1),flush=True)
main = ols('ols_main', s)
ols('ols_publisher_cluster', s, cluster=True)
threshold = float(s.copiesSold.quantile(.99))
RESULT['checks']['top_1pct_threshold'] = threshold
ols('ols_exclude_top1pct', s[s.copiesSold.le(threshold)])
ols('ols_nonzero_review', s[s.reviewScore.gt(0)], model_formula=formula.replace(' + zero_review',''))

# Conditional median estimates describe the central part of the conditional
# distribution; they do not refer to a separate sample of median-selling games.
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    med = smf.quantreg(formula, s).fit(q=.5, vcov='robust', max_iter=2000, p_tol=1e-6)
    record('median_main', med, s, 'Median regression, asymptotic robust standard errors', [str(x.message) for x in caught])

assert not any('Maximum number' in str(x.message) for x in caught), 'Quantile regression failed to converge'
RESULT['checks']['source_sha256_unchanged'] = hashlib.sha256(SOURCE.read_bytes()).hexdigest() == RESULT['source']['sha256']
RESULT['checks']['elapsed_seconds'] = time.time()-start
RESULT['versions'] = {'numpy': np.__version__, 'pandas': pd.__version__}
(OUT/'results.json').write_text(json.dumps(RESULT, indent=2, ensure_ascii=False, allow_nan=False))
print('Done', RESULT['checks']['elapsed_seconds'], flush=True)
